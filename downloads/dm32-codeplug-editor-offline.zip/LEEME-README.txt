DM32 Codeplug Editor — copia sin conexión / offline copy

ES  Abre codeplug-editor-es.html con cualquier navegador moderno (doble clic, sin servidor ni conexión).
    Edita canales, zonas, contactos, listas y ajustes, importa/exporta CSV y YAML de qdmr, y guarda el
    codeplug como .bin para escribirlo luego en la radio. La transferencia por USB necesita la app
    instalada o el sitio (https://donttellmeimcute.github.io/dm32-web-cps-flasher/).

EN  Open codeplug-editor-en.html in any modern browser (double click, no server, no connection).
    Edit channels, zones, contacts, lists and settings, import/export CSV and qdmr YAML, and save the
    codeplug as .bin to write to the radio later. USB transfer needs the installed app or the site
    (https://donttellmeimcute.github.io/dm32-web-cps-flasher/).
